// pro1 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1, 2, 3, 4" style="opacity: 1; transform: scale(1) translate3d(0px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 0ms; pointer-events: auto;">'+
// '<div class="property p1">'+
// '<div class="property-img">' +
//     '<div class="property-tag button alt featured">Características</div>' +
//     '<div class="property-tag button sale">En venta</div>' +
//     '<div class="property-price">$150,000</div>' +
//     '<img src="img/properties/properties-2.jpg" alt="fp" class="img-responsive">' +
//     '<div class="property-overlay">' +
//     '<a href="Detalle_inmueble.html" class="overlay-link">' +
//     '<i class="fa fa-link"></i>' +
//     '</a>' +
//     ' <a class="overlay-link property-video" title="Lexus GS F">' +
//     '<i class="fa fa-video-camera"></i>' +
//     ' </a>' +
//     '<div class="property-magnify-gallery">' +
//     ' <a href="img/properties/properties-2.jpg" class="overlay-link">' +
//     ' <i class="fa fa-expand"></i>' +
//     '</a>' +
//     '<a href="img/properties/properties-4.jpg" class="hidden"></a>' +
//     '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//     '</div>' +
//     '</div>' +
//     '</div>' +

//     '<div class="property-content">' +

//     '<h1 class="title">' +
//     '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//     '</h1>' +

//     '<h3 class="property-address">' +
//     '<a href="Detalle_inmueble.html">' +
//     '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
// '</a>' +
//     '</h3>' +

//     '<ul class="facilities-list clearfix">' +
//     '<li>' +
//     '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//     '<span>4800 Mts</span>' +
//     '</li>' +
//     '<li>' +
//     '<i class="flaticon-bed"></i>' +
//     '<span>3 Camas</span>' +
//     '</li>' +
//     ' <li>' +
//     '<i class="flaticon-monitor"></i>' +
//     '<span>TV </span>' +
//     '</li>' +
//     ' <li>' +
//     '<i class="flaticon-holidays"></i>' +
//     '<span> 2 Baños</span>' +
//     '</li>' +
//     '<li>' +
//     '<i class="flaticon-vehicle"></i>' +
//     '<span>1 Garage</span>' +
//     '</li>' +
//     '<li>' +

//     '<span> (Código)</span>' +
//     '</li>' +
//     '</ul>' +
//     '<div class="property-footer">' +
//     '<span class="left">' +
//     '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//     '</span>' +
//     ' <span class="right">' +
//     '<i class="fa fa-calendar"></i>5 Days ago'+
// '</span>' +
//     '</div>' +
//     '</div>' +
//     '</div>' +
//     '</div>'+
//     '</div>';


// pro2 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1, 4" style="opacity: 1; transform: scale(1) translate3d(323px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 1ms; pointer-events: auto;">'+
// '<div class="property p2">'+
// '<div class="property-img">' +
//     '<div class="property-tag button alt featured">Características</div>' +
//     '<div class="property-tag button sale">En venta</div>' +
//     '<div class="property-price">$150,000</div>' +
//     '<img src="img/properties/properties-3.jpg" alt="fp" class="img-responsive">' +
//     '<div class="property-overlay">' +
//     '<a href="Detalle_inmueble.html" class="overlay-link">' +
//     '<i class="fa fa-link"></i>' +
//     '</a>' +
//     ' <a class="overlay-link property-video" title="Lexus GS F">' +
//     '<i class="fa fa-video-camera"></i>' +
//     ' </a>' +
//     '<div class="property-magnify-gallery">' +
//     ' <a href="img/properties/properties-3.jpg" class="overlay-link">' +
//     ' <i class="fa fa-expand"></i>' +
//     '</a>' +
//     '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//     '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//     '</div>' +
//     '</div>' +
//     '</div>' +

//     '<div class="property-content">' +

//     '<h1 class="title">' +
//     '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//     '</h1>' +

//     '<h3 class="property-address">' +
//     '<a href="Detalle_inmueble.html">' +
//     '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
// '</a>' +
//     '</h3>' +

//     '<ul class="facilities-list clearfix">' +
//     '<li>' +
//     '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//     '<span>4800 Mts</span>' +
//     '</li>' +
//     '<li>' +
//     '<i class="flaticon-bed"></i>' +
//     '<span>3 Camas</span>' +
//     '</li>' +
//     ' <li>' +
//     '<i class="flaticon-monitor"></i>' +
//     '<span>TV </span>' +
//     '</li>' +
//     ' <li>' +
//     '<i class="flaticon-holidays"></i>' +
//     '<span> 2 Baños</span>' +
//     '</li>' +
//     '<li>' +
//     '<i class="flaticon-vehicle"></i>' +
//     '<span>1 Garage</span>' +
//     '</li>' +
//     '<li>' +

//     '<span> (Código)</span>' +
//     '</li>' +
//     '</ul>' +
//     '<div class="property-footer">' +
//     '<span class="left">' +
//     '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//     '</span>' +
//     ' <span class="right">' +
//     '<i class="fa fa-calendar"></i>5 Days ago'+
// '</span>' +
//     '</div>' +
//     '</div>' +
//     '</div>' +
//     '</div>'+
//     '</div>';

//     pro3 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" id="fl1" data-category="2, 3, 4" style="opacity: 1; transform: scale(1) translate3d(646px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 2ms; pointer-events: auto;">'+
//     '<div class="property p3">'+
//     '<div class="property-img">' +
//         '<div class="property-tag button alt featured">Características</div>' +
//         '<div class="property-tag button sale">En venta</div>' +
//         '<div class="property-price">$150,000</div>' +
//         '<img src="img/properties/properties-2.jpg" alt="fp" class="img-responsive">' +
//         '<div class="property-overlay">' +
//         '<a href="Detalle_inmueble.html" class="overlay-link">' +
//         '<i class="fa fa-link"></i>' +
//         '</a>' +
//         ' <a class="overlay-link property-video" title="Lexus GS F">' +
//         '<i class="fa fa-video-camera"></i>' +
//         ' </a>' +
//         '<div class="property-magnify-gallery">' +
//         ' <a href="img/properties/properties-2.jpg" class="overlay-link">' +
//         ' <i class="fa fa-expand"></i>' +
//         '</a>' +
//         '<a href="img/properties/properties-4.jpg" class="hidden"></a>' +
//         '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//         '</div>' +
//         '</div>' +
//         '</div>' +
    
//         '<div class="property-content">' +
    
//         '<h1 class="title">' +
//         '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//         '</h1>' +
    
//         '<h3 class="property-address">' +
//         '<a href="Detalle_inmueble.html">' +
//         '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
//     '</a>' +
//         '</h3>' +
    
//         '<ul class="facilities-list clearfix">' +
//         '<li>' +
//         '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//         '<span>4800 Mts</span>' +
//         '</li>' +
//         '<li>' +
//         '<i class="flaticon-bed"></i>' +
//         '<span>3 Camas</span>' +
//         '</li>' +
//         ' <li>' +
//         '<i class="flaticon-monitor"></i>' +
//         '<span>TV </span>' +
//         '</li>' +
//         ' <li>' +
//         '<i class="flaticon-holidays"></i>' +
//         '<span> 2 Baños</span>' +
//         '</li>' +
//         '<li>' +
//         '<i class="flaticon-vehicle"></i>' +
//         '<span>1 Garage</span>' +
//         '</li>' +
//         '<li>' +
    
//         '<span> (Código)</span>' +
//         '</li>' +
//         '</ul>' +
//         '<div class="property-footer">' +
//         '<span class="left">' +
//         '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//         '</span>' +
//         ' <span class="right">' +
//         '<i class="fa fa-calendar"></i>5 Days ago'+
//     '</span>' +
//         '</div>' +
//         '</div>' +
//         '</div>' +
//         '</div>'+
//         '</div>';



//         pro4 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1, 2, 3, 4" style="opacity: 1; transform: scale(1) translate3d(0px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 0ms; pointer-events: auto;">'+
//         '<div class="property p1">'+
//         '<div class="property-img">' +
//             '<div class="property-tag button alt featured">Características</div>' +
//             '<div class="property-tag button sale">En venta</div>' +
//             '<div class="property-price">$150,000</div>' +
//             '<img src="img/properties/properties-2.jpg" alt="fp" class="img-responsive">' +
//             '<div class="property-overlay">' +
//             '<a href="Detalle_inmueble.html" class="overlay-link">' +
//             '<i class="fa fa-link"></i>' +
//             '</a>' +
//             ' <a class="overlay-link property-video" title="Lexus GS F">' +
//             '<i class="fa fa-video-camera"></i>' +
//             ' </a>' +
//             '<div class="property-magnify-gallery">' +
//             ' <a href="img/properties/properties-2.jpg" class="overlay-link">' +
//             ' <i class="fa fa-expand"></i>' +
//             '</a>' +
//             '<a href="img/properties/properties-4.jpg" class="hidden"></a>' +
//             '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//             '</div>' +
//             '</div>' +
//             '</div>' +
        
//             '<div class="property-content">' +
        
//             '<h1 class="title">' +
//             '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//             '</h1>' +
        
//             '<h3 class="property-address">' +
//             '<a href="Detalle_inmueble.html">' +
//             '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
//         '</a>' +
//             '</h3>' +
        
//             '<ul class="facilities-list clearfix">' +
//             '<li>' +
//             '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//             '<span>4800 Mts</span>' +
//             '</li>' +
//             '<li>' +
//             '<i class="flaticon-bed"></i>' +
//             '<span>3 Camas</span>' +
//             '</li>' +
//             ' <li>' +
//             '<i class="flaticon-monitor"></i>' +
//             '<span>TV </span>' +
//             '</li>' +
//             ' <li>' +
//             '<i class="flaticon-holidays"></i>' +
//             '<span> 2 Baños</span>' +
//             '</li>' +
//             '<li>' +
//             '<i class="flaticon-vehicle"></i>' +
//             '<span>1 Garage</span>' +
//             '</li>' +
//             '<li>' +
        
//             '<span> (Código)</span>' +
//             '</li>' +
//             '</ul>' +
//             '<div class="property-footer">' +
//             '<span class="left">' +
//             '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//             '</span>' +
//             ' <span class="right">' +
//             '<i class="fa fa-calendar"></i>5 Days ago'+
//         '</span>' +
//             '</div>' +
//             '</div>' +
//             '</div>' +
//             '</div>'+
//             '</div>';
        
        
//         pro5 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" data-category="1, 4" style="opacity: 1; transform: scale(1) translate3d(323px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 1ms; pointer-events: auto;">'+
//         '<div class="property p2">'+
//         '<div class="property-img">' +
//             '<div class="property-tag button alt featured">Características</div>' +
//             '<div class="property-tag button sale">En venta</div>' +
//             '<div class="property-price">$150,000</div>' +
//             '<img src="img/properties/properties-3.jpg" alt="fp" class="img-responsive">' +
//             '<div class="property-overlay">' +
//             '<a href="Detalle_inmueble.html" class="overlay-link">' +
//             '<i class="fa fa-link"></i>' +
//             '</a>' +
//             ' <a class="overlay-link property-video" title="Lexus GS F">' +
//             '<i class="fa fa-video-camera"></i>' +
//             ' </a>' +
//             '<div class="property-magnify-gallery">' +
//             ' <a href="img/properties/properties-3.jpg" class="overlay-link">' +
//             ' <i class="fa fa-expand"></i>' +
//             '</a>' +
//             '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//             '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//             '</div>' +
//             '</div>' +
//             '</div>' +
        
//             '<div class="property-content">' +
        
//             '<h1 class="title">' +
//             '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//             '</h1>' +
        
//             '<h3 class="property-address">' +
//             '<a href="Detalle_inmueble.html">' +
//             '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
//         '</a>' +
//             '</h3>' +
        
//             '<ul class="facilities-list clearfix">' +
//             '<li>' +
//             '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//             '<span>4800 Mts</span>' +
//             '</li>' +
//             '<li>' +
//             '<i class="flaticon-bed"></i>' +
//             '<span>3 Camas</span>' +
//             '</li>' +
//             ' <li>' +
//             '<i class="flaticon-monitor"></i>' +
//             '<span>TV </span>' +
//             '</li>' +
//             ' <li>' +
//             '<i class="flaticon-holidays"></i>' +
//             '<span> 2 Baños</span>' +
//             '</li>' +
//             '<li>' +
//             '<i class="flaticon-vehicle"></i>' +
//             '<span>1 Garage</span>' +
//             '</li>' +
//             '<li>' +
        
//             '<span> (Código)</span>' +
//             '</li>' +
//             '</ul>' +
//             '<div class="property-footer">' +
//             '<span class="left">' +
//             '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//             '</span>' +
//             ' <span class="right">' +
//             '<i class="fa fa-calendar"></i>5 Days ago'+
//         '</span>' +
//             '</div>' +
//             '</div>' +
//             '</div>' +
//             '</div>'+
//             '</div>';
        
//             pro6 = '<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12  filtr-item" id="fl1" data-category="2, 3, 4" style="opacity: 1; transform: scale(1) translate3d(646px, 0px, 0px); backface-visibility: hidden; perspective: 1000px; transform-style: preserve-3d; position: absolute; transition: all 0.5s ease-out 2ms; pointer-events: auto;">'+
//             '<div class="property p3">'+
//             '<div class="property-img">' +
//                 '<div class="property-tag button alt featured">Características</div>' +
//                 '<div class="property-tag button sale">En venta</div>' +
//                 '<div class="property-price">$150,000</div>' +
//                 '<img src="img/properties/properties-2.jpg" alt="fp" class="img-responsive">' +
//                 '<div class="property-overlay">' +
//                 '<a href="Detalle_inmueble.html" class="overlay-link">' +
//                 '<i class="fa fa-link"></i>' +
//                 '</a>' +
//                 ' <a class="overlay-link property-video" title="Lexus GS F">' +
//                 '<i class="fa fa-video-camera"></i>' +
//                 ' </a>' +
//                 '<div class="property-magnify-gallery">' +
//                 ' <a href="img/properties/properties-2.jpg" class="overlay-link">' +
//                 ' <i class="fa fa-expand"></i>' +
//                 '</a>' +
//                 '<a href="img/properties/properties-4.jpg" class="hidden"></a>' +
//                 '<a href="img/properties/properties-3.jpg" class="hidden"></a>' +
//                 '</div>' +
//                 '</div>' +
//                 '</div>' +
            
//                 '<div class="property-content">' +
            
//                 '<h1 class="title">' +
//                 '<a href="Detalle_inmueble.html">Modern Family Home</a>' +
//                 '</h1>' +
            
//                 '<h3 class="property-address">' +
//                 '<a href="Detalle_inmueble.html">' +
//                 '<i class="fa fa-map-marker"></i>123 Kathal St. Tampa City,'+
//             '</a>' +
//                 '</h3>' +
            
//                 '<ul class="facilities-list clearfix">' +
//                 '<li>' +
//                 '<i class="flaticon-uare-layouting-with-black-uare-in-east-area"></i>' +
//                 '<span>4800 Mts</span>' +
//                 '</li>' +
//                 '<li>' +
//                 '<i class="flaticon-bed"></i>' +
//                 '<span>3 Camas</span>' +
//                 '</li>' +
//                 ' <li>' +
//                 '<i class="flaticon-monitor"></i>' +
//                 '<span>TV </span>' +
//                 '</li>' +
//                 ' <li>' +
//                 '<i class="flaticon-holidays"></i>' +
//                 '<span> 2 Baños</span>' +
//                 '</li>' +
//                 '<li>' +
//                 '<i class="flaticon-vehicle"></i>' +
//                 '<span>1 Garage</span>' +
//                 '</li>' +
//                 '<li>' +
            
//                 '<span> (Código)</span>' +
//                 '</li>' +
//                 '</ul>' +
//                 '<div class="property-footer">' +
//                 '<span class="left">' +
//                 '<a href="#"><i class="fa fa-user"></i>Jhon Doe</a>' +
//                 '</span>' +
//                 ' <span class="right">' +
//                 '<i class="fa fa-calendar"></i>5 Days ago'+
//             '</span>' +
//                 '</div>' +
//                 '</div>' +
//                 '</div>' +
//                 '</div>'+
//                 '</div>';

// var propiedades ='' ;
    
// var propiedades_des ='<div class="propiedades-dest"></div>';   
    




function ventanap() {
    $(".btn-des").css({ 'display': 'none' });
    $(".modal-body").append(propiedades_des);
   
}


function ventanap2(){
    $(".cont-p").css({ 'display': 'none' });
    $('.cont-p').append(propiedades);
    $(".cont").css({'display':'block'});
    
}
function prop1(){
    $("#property").append(pro1);
    $("#property").append(pro2);
    $("#property").append(pro3);
    $("#property").append(pro4);
    $("#property").append(pro5);
    $("#property").append(pro6);
    $("#fl1").css({'transform':' scale(1) translate3d(646px, 0px, 0px);'});
    $(".cont").css({'display':'none'});
}


